import { useState, createContext, useContext } from 'react';
import type { Role, Lang } from './types';
import { TRANSLATIONS } from './mockData';
import RoleSelector from './screens/RoleSelector';
import FarmerApp from './screens/farmer/FarmerApp';
import ParavetApp from './screens/paravet/ParavetApp';
import VetApp from './screens/vet/VetApp';
import LabApp from './screens/lab/LabApp';
import GovApp from './screens/government/GovApp';
import AdminApp from './screens/admin/AdminApp';

export interface AppCtx {
  role: Role | null;
  lang: Lang;
  isOnline: boolean;
  t: (key: string) => string;
  setLang: (l: Lang) => void;
  logout: () => void;
}

const Ctx = createContext<AppCtx>({
  role: null, lang: 'en', isOnline: true,
  t: (k) => k, setLang: () => {}, logout: () => {},
});

export const useApp = () => useContext(Ctx);

export default function App() {
  const [role, setRole] = useState<Role | null>(null);
  const [lang, setLang] = useState<Lang>('en');
  const [isOnline] = useState(true);

  const t = (key: string) => TRANSLATIONS[lang]?.[key] ?? TRANSLATIONS['en']?.[key] ?? key;

  const ctx: AppCtx = { role, lang, isOnline, t, setLang, logout: () => setRole(null) };

  if (!role) {
    return (
      <Ctx.Provider value={ctx}>
        <RoleSelector onSelect={setRole} />
      </Ctx.Provider>
    );
  }

  const screens: Record<Role, React.ReactNode> = {
    farmer:     <FarmerApp />,
    paravet:    <ParavetApp />,
    vet:        <VetApp />,
    lab:        <LabApp />,
    government: <GovApp />,
    admin:      <AdminApp />,
  };

  return (
    <Ctx.Provider value={ctx}>
      {screens[role]}
    </Ctx.Provider>
  );
}
